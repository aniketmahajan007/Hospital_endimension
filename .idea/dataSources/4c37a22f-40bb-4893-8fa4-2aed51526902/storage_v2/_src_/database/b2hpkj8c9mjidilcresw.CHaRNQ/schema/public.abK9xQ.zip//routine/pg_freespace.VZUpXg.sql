create function pg_freespace(rel regclass, OUT blkno bigint, OUT avail smallint) returns SETOF record
    parallel safe
    language sql
as
$$
SELECT blkno, pg_freespace($1, blkno) AS avail
  FROM generate_series(0, pg_relation_size($1) / current_setting('block_size')::bigint - 1) AS blkno;
$$;

alter function pg_freespace(regclass, out bigint, out smallint) owner to postgres;

